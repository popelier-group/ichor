#! /bin/bash

export KMP_AFFINITY=compact
export OMP_NUM_THREADS=1
ferebus=Ferebus-6.0_MPI-OMP-OptAlgebraSafe
mpirun -np 12 --map-by ppr:6:socket:PE=1 ../$ferebus #-output-filename SRECV ../$ferebus
